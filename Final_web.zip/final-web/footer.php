<?php
echo '<div>
<a href="index.php"><img src="images/logo2.png" alt="Image"></a>
</div>
<div class="section">
<ul>
    <li>
        <a href="index.php">Home</a>
    </li>
    <li>
        <a href="menu.php">Menu</a>
    </li>
    <li>
        <a href="locations.php">Locations</a>
    </li>
    <li>
        <a href="blog.php">Blog</a>
    </li>
    <li>
        <a href="about.php">About Us</a>
    </li>
    <li>
        <a href="schedule.php">Schedule</a>
    </li>
    <li>
        <a href="cart.php">Cart</a>
    </li>
</ul>
<div id="connect">
    <a href="https://www.facebook.com/HiroshimeNorikachi" target="_blank" id="facebook">Facebook</a>
    <a href="https://twitter.com/Mikuno59815440" target="_blank" id="twitter">Twitter</a>
    <a href="" target="_blank" id="googleplus">Google+</a>
</div>
</div>'
?>